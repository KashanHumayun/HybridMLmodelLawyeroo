/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.management.system;


/**
 *
 * @author Kashan
 */
public class Person {
    protected String name;
    protected long id;
    protected String password;
    protected int age;
    protected String address;
  
}
